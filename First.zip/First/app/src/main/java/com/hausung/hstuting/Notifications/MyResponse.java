package com.hausung.hstuting.Notifications;

public class MyResponse {

    public int success;
}
